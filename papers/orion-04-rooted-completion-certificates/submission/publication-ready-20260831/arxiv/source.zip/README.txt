ORION-04 journal source package

`manuscript.md` is the publication-clean rendering source. The repository's WAVE3_SCOPED_MANUSCRIPT_V3.md and CLAIM_LEDGER_V3.md remain the scientific authority and are intentionally not rewritten by this package.
