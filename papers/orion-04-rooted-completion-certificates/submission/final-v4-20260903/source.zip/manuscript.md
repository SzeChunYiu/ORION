---
title: "The fourth generalized Davenport constant of $C_5^3$"
author: "Sze Chun Yiu"
date: ""
---

**Affiliation:** Stockholm University

**Correspondence:** sze-chun.yiu@fysik.su.se

## Abstract

We determine the fourth generalized Davenport constant of the elementary abelian group $C_5^3$. The committed symbolic argument reduces the remaining case to the nonexistence of a length-31 total-zero sequence with no nonempty zero-sum subsequence of length at most five. Saturation restricts positive multiplicities to $1,2,4$. The admissible outer grammar contains 60 multiplicity patterns; a rank/plane decomposition yields 78 exhaustive branches. Two exact engines execute 156 registered runs and find zero survivors. A separately implemented Python/DP reconstruction independently regenerates the 60-pattern/78-branch cover without importing the production branch list or C search engines, and hostile mutations of the multiplicity equation, rank split, branch count, and result binding are rejected. Independent solver calibration and route-disagreement controls further test the primitive zero-sum predicate without consuming the protected target computation as authority. Therefore no length-31 obstruction exists, $31\in C_0(C_5^3)$, and
$$
D_4(C_5^3)=30.
$$
The committed recurrence then yields $D_k(C_5^3)=5k+10$ for every $k\ge2$. A refreshed submission-date priority audit (2026-09-02) found no retrieved source establishing this exact value, but it did establish that the lower-bound half is published: Theorem 4.1 of Freeze and Schmid (Discrete Math. 310 (2010) 3373–3389), instantiated at $s=3$, $t=1$, $\delta=1$, gives $D_k(C_5^3)\ge 13+6+1+5(k-2)=5k+10$ for every $k\ge2$. The contribution claimed here is therefore the matching upper bound — proving the Freeze–Schmid lower bound tight for $C_5^3$ from $k=2$ onward — and the paper avoids absolute “first” language for the exact value as well. External human proof review, externally checked per-branch certificates, and final custody/sign-off remain deferred to journal review or later independent validation and are not represented as locally earned authority.

## 1. Problem and theorem

For a finite abelian group $G$, let $D_k(G)$ be the least length forcing $k$ pairwise disjoint nonempty zero-sum subsequences. The lower-bound half of the corridor below is published prior work: Freeze and Schmid, Theorem 4.1 (Discrete Math. 310 (2010) 3373–3389), applied to $G=C_5^3$ with $s=3$, $t=1$ (the hypothesis $s(s-1)/2\le r-t+1$ holds with equality) and $\delta=1$ since $n_t=5$ is odd, gives
$$
D_k(C_5^3)\ \ge\ \mathsf D^*(C_5^3) + 3\lfloor 5/2\rfloor + 1 + (k-2)\cdot 5 \ =\ 5k+10\qquad(k\ge2).
$$
Earlier ORION-04 work established the width-one upper companion
$$
D_k(C_5^3)\le 5k+11\qquad(k\ge4),
$$
with the conditional implication
$$
D_4(C_5^3)=30\Longrightarrow D_k(C_5^3)=5k+10\qquad(k\ge2).
$$
Thus the unresolved numerical question was whether a length-31 total-zero sequence could avoid every zero-sum subsequence of lengths one through five — equivalently, whether the Freeze–Schmid lower bound is attained.

> **Theorem 1.** No length-31 total-zero sequence over $C_5^3$ is free of nonempty zero-sum subsequences of lengths one through five. Consequently $31\in C_0(C_5^3)$, $D_4(C_5^3)=30$, and $D_k(C_5^3)=5k+10$ for every $k\ge2$.

The proof is finite and computer-assisted. Generic recurrence, localization, saturation, and projective-space results used as premises remain donor mathematics.

## 2. Finite grammar and branch cover

Let $S$ be a hypothetical obstruction. Saturation restricts every positive multiplicity to $1,2,4$. If $a_1,b_2,c_4$ count support points of those multiplicities, then
$$
a_1+b_2+c_4=s,\qquad a_1+2b_2+4c_4=31.
$$
These equations generate 60 admissible multiplicity patterns. Prior exact work excludes support at most 13. The remaining supports 14--31 are covered by a rank/plane decomposition with 51 lower-support branches and 27 upper-support branches.

For supports 14--22, the high-multiplicity subsequence either forces rank three through the $\eta(C_5^2)=13$ bound, supplies a rank-three basis through four multiplicity-four points, or enters an explicit rank-two plane case when $c_4=3$. For supports 23--31, the high-support set is partitioned by rank and multiplicity profile; normalized bases and the same $\eta(C_5^2)$ restriction remove impossible rank-two cases. The resulting cover contains exactly 78 branches.

## 3. Exact search

The frozen target computation uses two exact engines with different state representations. Each tracks all group sums reachable at exact weights zero through five and rejects a partial sequence as soon as zero becomes reachable in a forbidden weight layer. Across 78 branches and two engines, 156 registered runs complete with agreement on the frozen branch fingerprints and zero solution count in every branch.

An off-host replay using the same committed source but a different compiler major version and native instruction target reproduces the exact result and cover digests. This replay is an independent execution of the same source; it is not used as the independent implementation claim.

## 4. Independent reconstruction and adversarial verification

The independent A1 reconstruction does not import the production branch list, the production C engines, current fingerprints, or generator output. Starting from the multiplicity equations and rank/plane lemmas, it independently regenerates:

- the 60 admissible multiplicity patterns;
- the projective-line admissibility structure;
- the 51 lower-support branches;
- the 27 upper-support branches;
- the exact 78-branch partition.

Only after reconstruction is the independently generated tuple set compared with the committed production cover. The comparison is exact: no missing and no extra branches.

The independent route uses a materially different Python/DP representation rather than a line-by-line translation of the production C search. Additional Z3/SMT calibration tests the primitive disjoint-zero-sum predicate on frozen published small-group controls and agrees with separately implemented brute-force occurrence assignment on exhaustive small domains. Route-disagreement controls require unanimity among distinct routes and terminate adversely or `CANNOT_CHECK` rather than using majority vote when routes disagree or disappear.

Hostile controls reject, among others, an omitted branch, an altered total-length equation, a deleted or modified rank split, an altered eta threshold, a forged zero-solution digest, and a checksum-consistent forged nonzero-survivor result. These controls test that acceptance depends on mathematical and semantic content rather than only on file identity.

## 5. Proof of Theorem 1

Assume a length-31 total-zero short-zero-free sequence exists. Saturation forces its positive multiplicities into $\{1,2,4\}$, hence its support belongs to the 60-pattern equation-generated grammar. Prior work excludes support at most 13. The independently reconstructed rank/plane decomposition covers every remaining admissible support pattern by one of the 78 branches. The frozen exact computation exhausts every branch using two representations and records zero survivors in all 156 runs. Therefore the assumed obstruction does not exist. Hence $31\in C_0(C_5^3)$. Combined with the previously established corridor, this gives $D_4(C_5^3)=30$; the committed recurrence then yields $D_k(C_5^3)=5k+10$ for every $k\ge2$. $\square$

## 6. Priority and novelty scope

A dedicated priority audit, refreshed 2026-09-02 with ORION vocabulary stripped (record: `PRIORITY_AUDIT_ADDENDUM_2026-09-02.md`), found no retrieved source that already establishes the exact value $D_4(C_5^3)=30$ or any exact $D_k(C_5^3)$, and found that the lower bound $D_k(C_5^3)\ge 5k+10$ $(k\ge2)$ is a direct instance of Freeze–Schmid Theorem 4.1, as stated in Section 1. Supporting the exact value being otherwise open: $\eta(C_5^3)$ has no published exact value (Fan–Gao–Zhong, J. Number Theory 131 (2011), prove $s(C_5^3)=\eta(C_5^3)+4$ only), so no exact $D_k(C_5^3)$ follows from the known upper-bound machinery, and the 2025 state of the art (Zhong, Combinatorica) records exact $D_k$ values only for rank at most two, elementary 2-groups of rank at most five, and $C_3^3$. MathSciNet and zbMATH were not accessible to this audit and remain explicitly `CANNOT_CHECK`; the audit closes the local literature task but is not an omniscient global priority certificate. The manuscript therefore states the exact theorem and its relation to the closest retrieved work while avoiding absolute “first”, “unique”, or equivalent language.

The nearest published exact rank-three companion sharpens what is new here. For $C_3^3$ (Bhowmik–Schlage-Puchta 2007, as recorded by Freeze–Schmid Remark 5.3), the known values are $D_1=7$, $D_2=11$, and $D_k=3k+6$ for $k\ge3$: the Freeze–Schmid bound $D_k(C_3^3)\ge 3k+5$ is attained at $k=2$ but strictly exceeded from $k=3$ onward. The present theorem shows the opposite regime for $C_5^3$: the Freeze–Schmid bound is attained for every $k\ge2$. Where the tightness threshold sits as a function of $p$ for $C_p^3$ is, to our retrieval, open, and the $p=3$ versus $p=5$ contrast is stated as data rather than explained.

The paper does not claim novelty of generic Davenport machinery, saturation, projective-space methods, recurrence arguments, or exact-search methodology in the abstract, and it does not claim the lower bound, which is Freeze–Schmid's. The contribution claimed here is the matching upper bound and hence exactness — the exact bounded theorem, its finite branch reduction, and the independently reconstructed verification path for this instance.

## 7. External-review boundary

The following items remain intentionally external and are **not** represented as locally completed:

1. a signed independent mathematical proof review by a person outside the authoring process;
2. externally checked per-branch certificate and output manifests;
3. final independent custody/authorization receipts where a venue or archive requires them;
4. journal peer review and editorial acceptance.

These items are deferred to journal review or later independent validation. Their absence does not erase the locally established theorem or block completion of the local submission package, but it does block any claim that external peer review, external custody, or independent human proof validation has already occurred.

## 8. Reproducibility and evidence map

The exact authority packet is `evidence/global-obstruction-v1/`. Independent reconstruction material is in `evidence/a1-independent-branch-audit-v1/`. The archive-readiness machinery is in `evidence/a1-theorem-packet-archive-v1/`. The latter is designed to fail closed when external review/custody receipts are absent; that fail-closed status is preserved rather than bypassed.

The local submission posture is therefore:

- exact theorem: established by the committed finite computation and proof chain;
- independent implementation/reconstruction: locally complete;
- mutation/adversarial controls: locally complete;
- priority audit: locally complete, with absolute priority language withheld;
- external human proof review/custody: deferred and explicitly unclaimed;
- editorial acceptance: unclaimed.

## 9. Conclusion

The remaining one-unit branch for the fourth generalized Davenport constant of $C_5^3$ is closed: $D_4(C_5^3)=30$. The committed recurrence then gives $D_k(C_5^3)=5k+10$ for every $k\ge2$. The result is supported by an exhaustive 60-pattern/78-branch reduction, two exact target-search representations, an independently regenerated Python/DP cover, solver calibration, off-host replay, and hostile semantic controls. The paper is locally ready for submission-package completion. External human proof audit, external certificate checking, and journal review remain visible deferred validation rather than artificial blockers on local completion.

# Related work and novelty boundary

The generalized Davenport constants ask for the least sequence length forcing a
prescribed number of pairwise disjoint nontrivial zero-sum subsequences. For
rank-two groups an exact linear formula is known, and recent inverse work
studies the extremal structure at that solved boundary [Zhong 2025]. For
general finite abelian groups the sequence is eventually linear in the index
[Freeze–Schmid 2010], but the rank-three elementary setting is not covered by
the rank-two formula. Nearby rank-three work studies other zero-sum invariants
rather than the same generalized Davenport constant [Zhang 2023]. Standard
background is provided by the zero-sum survey of Gao and Geroldinger and the
monograph of Geroldinger and Halter-Koch.

The lower-bound half of the paper's formula is published prior work: Theorem
4.1 of Freeze and Schmid, instantiated at `s=3`, `t=1`, `delta=1`,
gives `D_k(C_5^3) >= 5k+10` for every `k>=2`. The exact rank-three
companion `C_3^3` [Bhowmik–Schlage-Puchta 2007, recorded in Freeze–Schmid
Remark 5.3] attains that bound only at `k=2` and exceeds it from `k=3`
onward. No exact value of `eta(C_5^3)` is published [Fan–Gao–Zhong 2011
prove `s(C_5^3)=eta(C_5^3)+4` without determining either constant], so no
exact `D_k(C_5^3)` follows from the known upper-bound machinery.

The current paper's contribution is the matching upper bound and hence
exactness: it proves `D_4(C_5^3)=30`, so the Freeze–Schmid lower bound is
tight for `C_5^3` from `k=2` onward — the opposite tightness regime from
`C_3^3`, stated as data. The residual novelty claim is confined to this
bounded computer-assisted theorem and its checked decomposition; it is not a
new general recurrence theory, and the lower bound is not claimed.

The primary-source review was refreshed on 2026-09-02 with a PARTIAL verdict
(record: `PRIORITY_AUDIT_ADDENDUM_2026-09-02.md`): no retrieved source states
the exact value `D_4(C_5^3)=30` or any exact `D_k(C_5^3)`; MathSciNet and
zbMATH were not accessible and remain CANNOT_CHECK. Accordingly the paper
makes no "first", "unique", or exhaustive-nearest-work claim; a closer source
found during editorial review should narrow positioning without changing the
checked theorem statement.

## References

- M. Freeze and W. A. Schmid, "Remarks on a generalization of the Davenport
  constant," *Discrete Mathematics* 310(23), 3373–3389 (2010).
  DOI: 10.1016/j.disc.2010.04.019. arXiv:0905.4248.
- G. Bhowmik and J.-C. Schlage-Puchta, "Davenport's constant for groups of
  the form Z3 + Z3 + Z3d," in *Additive Combinatorics*, CRM Proc. Lecture
  Notes 43, AMS, 307–326 (2007).
- Y. Fan, W. Gao, and Q. Zhong, "On the Erdős–Ginzburg–Ziv constant of finite
  abelian groups of high rank," *Journal of Number Theory* 131(10),
  1864–1874 (2011). DOI: 10.1016/j.jnt.2011.03.004.
- W. Gao and A. Geroldinger, "Zero-sum problems in finite abelian groups: a
  survey," *Expositiones Mathematicae* 24(4), 337–369 (2006).
  DOI: 10.1016/j.exmath.2006.07.002.
- A. Geroldinger and F. Halter-Koch, *Non-Unique Factorizations: Algebraic,
  Combinatorial and Analytic Theory*, Chapman & Hall/CRC (2006).
- Q. Zhong, "On the Inverse Problem of the k-th Davenport Constants for
  Groups of Rank 2," *Combinatorica* (2025). arXiv:2503.21231.
- C. Zhang, rank-three zero-sum invariants, arXiv:2310.05458 (2023).
