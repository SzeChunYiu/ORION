#!/usr/bin/env python3
"""Independent standard-library replay of the bounded mapping comparison."""
from __future__ import annotations
import json, math, random
from pathlib import Path
from statistics import mean
ROOT=Path(__file__).resolve().parent
SEED=20260817
RESAMPLES=10_000
COMPATIBLE='COMPATIBLE'
UNRESOLVED='UNRESOLVED'
NONMERGE={'CONTRADICTORY','CONTEXTUAL_DIFFERENCE','DISTINCT_REFERENT','DISTINCT_CONSTRUCT','DISTINCT_MEASUREMENT'}
LIST_FIELDS=('argument_roles','referent_ids','construct_ids','measurement_ids','temporal_context_ids','assumption_ids','unresolved_ambiguities')
TEXT_FIELDS=('predicate','discourse_relation','attribution_id')
def load(name):
 return [json.loads(x) for x in (ROOT/'data'/name).read_text().splitlines() if x.strip()]
def as_list(p,f):
 v=p.get(f,[])
 return tuple(tuple(x) if isinstance(x,list) else x for x in v)
def as_text(p,f,d=''):
 return p.get(f,d)
def coordinate(case):
 left,right=case['left_projection'],case['right_projection']
 if as_list(left,'unresolved_ambiguities') or as_list(right,'unresolved_ambiguities'): return UNRESOLVED
 if as_text(left,'predicate')!=as_text(right,'predicate'): return UNRESOLVED
 for field,relation in (('referent_ids','DISTINCT_REFERENT'),('construct_ids','DISTINCT_CONSTRUCT'),('measurement_ids','DISTINCT_MEASUREMENT')):
  a,b=as_list(left,field),as_list(right,field)
  if a and b and a!=b:return relation
 for field in ('temporal_context_ids','assumption_ids'):
  a,b=as_list(left,field),as_list(right,field)
  if a and b and a!=b:return 'CONTEXTUAL_DIFFERENCE'
 for field in ('attribution_id','discourse_relation'):
  a,b=as_text(left,field),as_text(right,field)
  if a and b and a!=b:return 'CONTEXTUAL_DIFFERENCE'
 lm,rm=as_text(left,'modality','UNKNOWN'),as_text(right,'modality','UNKNOWN')
 if lm!=rm:return 'CONTEXTUAL_DIFFERENCE'
 lp,rp=as_text(left,'polarity','UNKNOWN'),as_text(right,'polarity','UNKNOWN')
 if lp!='UNKNOWN' and rp!='UNKNOWN' and lp!=rp:
  return 'CONTRADICTORY' if lm==rm=='ASSERTED' else 'CONTEXTUAL_DIFFERENCE'
 return COMPATIBLE
def flat(case):
 l,r=case['left_projection'],case['right_projection']
 return COMPATIBLE if as_text(l,'predicate')==as_text(r,'predicate') else UNRESOLVED
def normalized(p):
 return (*(as_text(p,f) for f in TEXT_FIELDS),*(as_list(p,f) for f in LIST_FIELDS),as_text(p,'polarity','UNKNOWN'),as_text(p,'modality','UNKNOWN'))
def exact(case):
 return COMPATIBLE if normalized(case['left_projection'])==normalized(case['right_projection']) else UNRESOLVED
def vectors(gold,pred):
 return {'accuracy':[float(g==p) for g,p in zip(gold,pred)],'false_merge':[float(g in NONMERGE and p==COMPATIBLE) for g,p in zip(gold,pred)],'false_split':[float(g==COMPATIBLE and p in NONMERGE) for g,p in zip(gold,pred)],'abstention':[float(p==UNRESOLVED) for p in pred]}
def percentile(v,q):
 s=sorted(v); pos=q*(len(s)-1); lo,hi=math.floor(pos),math.ceil(pos)
 return s[lo] if lo==hi else s[lo]*(hi-pos)+s[hi]*(pos-lo)
def paired(a,b):
 d=[x-y for x,y in zip(a,b)]; rng=random.Random(SEED); boot=[mean(rng.choices(d,k=len(d))) for _ in range(RESAMPLES)]
 return {'difference':mean(d),'bootstrap_95_interval':[percentile(boot,.025),percentile(boot,.975)]}
def main():
 initial,confirmatory=load('initial_cases.jsonl'),load('confirmatory_cases.jsonl')
 expected=json.loads((ROOT/'expected_results.json').read_text())
 if len(initial)!=32 or len(confirmatory)!=32:raise SystemExit('case count mismatch')
 if {x['case_label'] for x in initial}&{x['case_label'] for x in confirmatory}:raise SystemExit('case-label overlap')
 shared=set(r for x in initial for r in x['source_references'])&set(r for x in confirmatory for r in x['source_references'])
 gold=[x['expected']['meaning_relation'] for x in confirmatory]
 predictions={'coordinate_governed':[coordinate(x) for x in confirmatory],'flat_predicate':[flat(x) for x in confirmatory],'exact_coordinate':[exact(x) for x in confirmatory]}
 vec={k:vectors(gold,p) for k,p in predictions.items()}
 systems={k:{m:mean(values) for m,values in vv.items()} for k,vv in vec.items()}
 diffs={'false_merge_coordinate_minus_flat':paired(vec['coordinate_governed']['false_merge'],vec['flat_predicate']['false_merge']),'false_split_coordinate_minus_exact':paired(vec['coordinate_governed']['false_split'],vec['exact_coordinate']['false_split'])}
 got={'sets':{'initial_cases':len(initial),'confirmatory_cases':len(confirmatory),'case_label_overlap':0,'shared_public_source_records':len(shared)},'systems':systems,'paired_differences':diffs,'predeclared_rule_pass':diffs['false_merge_coordinate_minus_flat']['difference']<=-.05 and diffs['false_merge_coordinate_minus_flat']['bootstrap_95_interval'][1]<0 and diffs['false_split_coordinate_minus_exact']['difference']<=.03 and diffs['false_split_coordinate_minus_exact']['bootstrap_95_interval'][1]<=.03,'boundaries':expected['boundaries']}
 if got!=expected:
  print(json.dumps(got,indent=2,sort_keys=True)); raise SystemExit('replay differs from expected results')
 print(json.dumps(got,indent=2,sort_keys=True)); print('PASS')
if __name__=='__main__':main()
