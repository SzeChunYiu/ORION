# Review materials

These materials reproduce the bounded confirmatory comparison for coordinate-governed mapping of source-local scientific projections. The archive contains 32 initial cases, 32 case-label-disjoint confirmatory cases, a standard-library replay, and expected aggregate results.

Run `python verify.py`. The replay implements the coordinate-governed rule and two controls directly, imports no generating analysis module, recomputes the four reported rates and paired bootstrap intervals, and compares them with `expected_results.json`.

The confirmatory cases have no case-label overlap with the initial set, but two public source records occur in both sets. The evidence therefore does not establish source-disjoint replication. The replay is an independent implementation under the same repository custody, not external replication. It does not evaluate raw-text generalization, an expert atlas, downstream utility, or broader autonomous-system claims.

Archive-local case and source-record labels are descriptive only and carry no project or release meaning. Public access hosting and venue-specific author declarations remain filing-time responsibilities.
