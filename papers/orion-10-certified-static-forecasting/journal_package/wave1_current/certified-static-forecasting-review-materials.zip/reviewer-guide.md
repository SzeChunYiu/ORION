# Reviewer guide

## What is proved
The unit-objective unrestricted optimum equals the support-at-most-two optimum for every qubit count in the stated grammar. A separate complete local-domain argument classifies each optimum into three reader-named structural families.

## What is checked finitely
The benchmark, prospective rows, hostile explanation test, hybrid-family corpus, and executable evaluator are finite checks. They validate the implementation and expose counterexamples; they are not substituted for the all-size proofs.

## Adverse evidence to inspect
- One three-qubit input has exact cost 10 and simple-formula cost 11.
- The first enlarged explanation fails on 64 of 740 hostile cases.
- Two simpler proof routes fail and remain reported.
- A changed objective has costs 11, 13, and 23 for the unrestricted, support-two, and weight-one families; the main theorem does not transfer.

Run `python verify.py` to check the published arithmetic and inequalities in the machine-readable summary. The checker is intentionally modest: it does not claim to reproduce the full all-size searches.
