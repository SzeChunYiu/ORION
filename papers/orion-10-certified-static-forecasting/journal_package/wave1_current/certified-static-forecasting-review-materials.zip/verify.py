#!/usr/bin/env python3
import json
from pathlib import Path
d=json.loads((Path(__file__).parent/'evidence-summary.json').read_text())
a=d['initial_comparison']
assert a['structured_two_qubit']+a['seeded_two_and_three_qubit']+a['application_derived']==a['distinct_inputs']==9546
assert a['matches']+a['mismatches']==a['distinct_inputs']
assert (a['matches'],a['mismatches'])==(9545,1)
p=d['prospective_panel']; assert p['public_library_rows']+p['engineered_rows']==p['staged_rows']==p['matches']==102
c=d['retained_counterexample']; assert c['exact_cost']==10<c['simple_formula_cost']==11
e=d['exact_evaluator']; assert e['comparison_events']==e['distinct_inputs']+1 and e['nonzero_errors']==0 and not e['unrestricted_optimizer_called_in_forecast_path']
s=d['support_proof']; assert s['local_inequality_cases']==18432 and s['violations']==0 and s['support_two_boundary_patterns']==4
h=d['enlarged_explanation_hostile_test']; assert (h['failures'],h['exact_cases'],h['gap_each'])==(64,740,1)
f=d['hybrid_finite_test']; assert f['verified_inputs']==10481 and f['uncovered']==0 and not f['all_size_proof_source']
t=d['all_size_explanation_proof']; assert t['geometries']==378 and t['states_per_geometry']==2**24 and t['residue']==0
r=d['retained_failed_routes']; assert r['replacement_images']==10 and r['single_pinner_composite_configurations']==133349376 and r['two_coordinate_premise_refuted']
w=d['reweighted_boundary']; assert w['unrestricted_cost']==11<w['support_two_cost']==13<w['weight_one_cost']==23 and w['support_two_failures_in_panel']==53
assert not d['runtime_claimed']
print('All published aggregate checks passed.')
