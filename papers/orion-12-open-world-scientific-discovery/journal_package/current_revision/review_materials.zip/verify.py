#!/usr/bin/env python3
"""Standard-library check of the bounded review materials."""
from __future__ import annotations
import json,math,random
from pathlib import Path
from statistics import mean
ROOT=Path(__file__).resolve().parent
SEED=20260828
RESAMPLES=10_000
def load(name):return json.loads((ROOT/'data'/name).read_text())
def percentile(values,q):
 s=sorted(values); pos=q*(len(s)-1); lo,hi=math.floor(pos),math.ceil(pos)
 return s[lo] if lo==hi else s[lo]*(hi-pos)+s[hi]*(pos-lo)
def bootstrap(diffs):
 rng=random.Random(SEED); b=[mean(rng.choices(diffs,k=len(diffs))) for _ in range(RESAMPLES)]
 return [percentile(b,.025),percentile(b,.975)]
def main():
 topics=load('external_retrieval_topics.json'); expected=json.loads((ROOT/'expected_results.json').read_text())
 if len(topics)!=50:raise SystemExit('topic count mismatch')
 macro={}
 for arm in ('lexical_baseline','reciprocal_rank_fusion','governed_controller','diagnostic_closure_variant'):
  macro[arm]={'recall_at_100':round(mean(x['arms'][arm]['recall_at_100'] for x in topics),6),'ndcg_at_10':round(mean(x['arms'][arm]['ndcg_at_10'] for x in topics),6),'mean_reads':round(mean(x['arms'][arm]['reads'] for x in topics),2),'mean_route_calls':round(mean(x['arms'][arm]['route_calls'] for x in topics),1)}
 if macro!=expected['external_retrieval']['macro']:raise SystemExit('external macro mismatch')
 recall=[x['arms']['governed_controller']['recall_at_100']-x['arms']['lexical_baseline']['recall_at_100'] for x in topics]
 ndcg=[x['arms']['governed_controller']['ndcg_at_10']-x['arms']['lexical_baseline']['ndcg_at_10'] for x in topics]
 recall_ci=bootstrap(recall); ndcg_ci=bootstrap(ndcg)
 if mean(recall)>=0 or recall_ci[0]>=expected['external_retrieval']['recall_noninferiority_margin']:raise SystemExit('adverse recall decision not reproduced')
 if macro['governed_controller']['mean_reads']<=macro['lexical_baseline']['mean_reads']:raise SystemExit('adverse reading-cost direction not reproduced')
 if mean(ndcg)<=0 or ndcg_ci[0]<=0:raise SystemExit('secondary top-rank direction not reproduced')
 if load('controlled_index_summary.json')!=expected['controlled_index']:raise SystemExit('controlled-index summary mismatch')
 if load('exact_contract_summary.json')!=expected['exact_contract']:raise SystemExit('exact-contract summary mismatch')
 print(json.dumps({'external_macro':macro,'independent_recall_interval':recall_ci,'independent_top_rank_interval':ndcg_ci,'registered_gate_passed':False,'controlled_and_exact_summaries_match':True},indent=2,sort_keys=True));print('PASS')
if __name__=='__main__':main()
