# Review materials

These reader-facing materials support the bounded control-method paper on fail-closed scientific-literature discovery. They retain the complete-gold controlled results, the exact-contract comparison, the adverse public external retrieval test, and additional negative or undetermined external probes.

Run `python verify.py`. The standard-library checker recomputes external macro outcomes from 50 paired public-collection topics, runs a separate fixed-seed paired bootstrap as a robustness replay, and checks the controlled-index and exact-contract aggregates against `expected_results.json`. Its independent bootstrap is a decision robustness check; the registered interval reported in the manuscript remains explicitly listed in the expected-results file.

The controlled comparison is underpowered and does not establish superiority. The registered external recall-and-cost gate fails: recall is lower and reading cost is higher. A favorable top-rank result is secondary and does not replace those criteria. The information-equivalent exact-contract comparator ties the fail-closed controller, so the protected comparison isolates unresolved-route semantics rather than inherent model expressivity.

Archive-local scientific names carry no project or release meaning. Original provenance and integrity records remain private and are not reader-facing.
