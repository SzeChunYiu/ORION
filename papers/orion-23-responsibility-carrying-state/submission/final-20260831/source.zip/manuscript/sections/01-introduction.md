# Introduction

Compression, abstraction and state reuse are normally evaluated against a named objective. Problems appear when compact state is reused after the downstream responsibility changes. A summary sufficient for a factual question may omit provenance needed to authorize a scientific claim. A proof-state abstraction useful for next-tactic prediction may omit dependencies needed to diagnose or repair a failed proof. A control-state abstraction adequate for one policy may collapse distinctions needed for intervention or counterfactual analysis.

This is not merely an uncertainty problem. A system can be highly confident while state omits a variable that becomes decisive under a new responsibility. Nor is it merely provenance: knowing exactly where state came from does not establish what that state can safely support.

ORION-23 asks:

> **Can a compact state carry a machine-checkable responsibility contract that says what it supports, what it omits, what changes invalidate reuse, and whether richer state can be reopened—without forcing every decision to reload raw evidence?**

The paper contributes responsibility-relative sufficiency; a responsibility-carrying state interface; permanent negative-result analysis; and an outcome-contingency adjudication that separates the exact supported core from descriptive P13A measurements whose empirical safety–cost authority is withheld.
