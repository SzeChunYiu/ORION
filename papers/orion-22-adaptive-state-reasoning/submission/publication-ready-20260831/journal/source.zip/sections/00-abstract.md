Test-time scaling is usually framed as deciding how much more reasoning to
perform. We study a different decision: where computation should be spent
between state construction and downstream reasoning. An initial comparison is
retained as historical because its action capabilities differed. A
prospectively frozen equal-action successor isolates signal complementarity:
across 32 independent simulated family blocks, the two-signal policy improves
exact allocation accuracy over the stronger one-signal policy by 0.253906
(stratified family-block 95% interval 0.251221–0.256653).

We then freeze one q/c/B allocation rule and apply it unchanged to SAT
propagation, grid path planning and 0/1 knapsack. It matches the hindsight
resource-location oracle in all nine protected cases, while reason-only and
always-materialize restrictions incur positive regret in every domain. A
preregistered stress study supplies the critical negative: the q-greedy rule's
FLAT result replicates, but its price and distribution-shift axes are both
**BROKEN**. A separately preregistered price-aware successor reaches zero regret
in all 195 frozen cells when given exact published per-structure charge
certificates; independent implementations agree. Formal falsifiers support the
necessity/sufficiency boundary for exact certificate fields in the registered
finite environment. These are bounded internal exact-domain results, not
ScienceAgentBench, naturalistic-agent, forward-time-certificate, or external
validation.
