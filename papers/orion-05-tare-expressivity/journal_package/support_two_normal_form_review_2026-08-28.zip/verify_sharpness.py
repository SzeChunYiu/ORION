#!/usr/bin/env python3
"""Recompute the displayed paired-instance sharpness result."""

import json
from direct_solver import SparseGrammar, solve_matching, verify_witness


TARGET_PAIRS = (
    ((1, 0), (1, 0)),  # XI, XI
    ((1, 0), (1, 0)),  # XI, XI
    ((0, 1), (0, 2)),  # IX, IY
)


def main() -> None:
    grammar_two = SparseGrammar(2, max_support=2)
    grammar_one = SparseGrammar(2, max_support=1)
    witness_two = solve_matching(TARGET_PAIRS, grammar=grammar_two, max_support=2)
    witness_one = solve_matching(TARGET_PAIRS, grammar=grammar_one, max_support=1)
    checks_two = verify_witness(TARGET_PAIRS, witness_two)
    checks_one = verify_witness(TARGET_PAIRS, witness_one)
    assert witness_two.cost == 5
    assert witness_one.cost == 6
    assert all(checks_two.values()) and all(checks_one.values())
    print(json.dumps({
        "schema": "anonymous-review.sharpness.v1",
        "target_pairs": [["XI", "XI"], ["XI", "XI"], ["IX", "IY"]],
        "support_two_cost": witness_two.cost,
        "support_one_cost": witness_one.cost,
        "support_two_witness": witness_two.as_dict(),
        "support_one_witness": witness_one.as_dict(),
        "support_two_checks": checks_two,
        "support_one_checks": checks_one,
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
