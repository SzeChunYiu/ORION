#!/usr/bin/env python3
"""Audit all retained runtime rows and regenerate their adverse summary."""

import argparse
import json
import statistics
from pathlib import Path


HERE = Path(__file__).resolve().parent
METRICS = ("wall_ns", "cpu_ns", "peak_rss_kib", "verification_ns")


def load_rows():
    return [json.loads(line) for line in (HERE / "runtime_attempts.jsonl").read_text().splitlines() if line]


def completed(rows):
    return [row for row in rows if row["status"] == "COMPLETED"]


def medians(rows):
    done = completed(rows)
    return {
        metric: (float(statistics.median(int(row[metric]) for row in done)) if done else None)
        for metric in METRICS
    }


def cell(row):
    return row["subject"], int(row["pairing_index"]), row["projection"]


def expected_attempt_ids(spec, rows):
    panel = spec["panel"]
    repeats = int(panel["completed_cell_repeats"])
    correctness = set(panel["correctness_projections"])
    scale = set(panel["scale_projections"])
    by_id = {row["attempt_id"]: row for row in rows}
    expected = set()
    for subject in sorted(spec["subjects"]):
        for pairing in panel["pairing_indices"]:
            for projection in panel["projections"]:
                qlabel = "full" if projection == "full_subject" else str(projection)
                for algorithm in ("support_two", "unrestricted"):
                    initial_repeats = repeats if projection in correctness or algorithm == "unrestricted" else 1
                    for repeat in range(initial_repeats):
                        expected.add(f"{subject}-pairing{int(pairing):02d}-qubits{qlabel}-{algorithm}-repeat{repeat}")
                    first = f"{subject}-pairing{int(pairing):02d}-qubits{qlabel}-{algorithm}-repeat0"
                    if algorithm == "support_two" and projection in scale and by_id.get(first, {}).get("status") == "COMPLETED":
                        for repeat in range(1, repeats):
                            expected.add(f"{subject}-pairing{int(pairing):02d}-qubits{qlabel}-{algorithm}-repeat{repeat}")
    return expected


def summarize():
    specification_path = HERE / "runtime_specification.json"
    environment_path = HERE / "runtime_environment.json"
    spec = json.loads(specification_path.read_text())
    rows = load_rows()
    ids = [row.get("attempt_id") for row in rows]
    assert None not in ids and len(ids) == len(set(ids))
    assert set(ids) == expected_attempt_ids(spec, rows)
    assert all(row.get("measurement_sources_verified_before_run") is True for row in rows)

    grouped = {}
    for row in rows:
        grouped.setdefault((row["algorithm"], *cell(row)), []).append(row)
    correctness_keys = {
        (subject, int(pairing), projection)
        for subject in spec["subjects"]
        for pairing in spec["panel"]["pairing_indices"]
        for projection in spec["panel"]["correctness_projections"]
    }
    full_keys = {
        (subject, int(pairing), "full_subject")
        for subject in spec["subjects"]
        for pairing in spec["panel"]["pairing_indices"]
    }
    repeats = int(spec["panel"]["completed_cell_repeats"])

    def complete_valid(algorithm, keys):
        return all(
            len(completed(grouped.get((algorithm, *key), []))) >= repeats
            and all(row.get("witness_valid") is True for row in completed(grouped.get((algorithm, *key), [])))
            for key in keys
        )

    cost_rows = []
    equal = True
    all_keys = sorted({cell(row) for row in rows}, key=str)
    for key in all_keys:
        left = completed(grouped.get(("unrestricted", *key), []))
        right = completed(grouped.get(("support_two", *key), []))
        if not left or not right:
            continue
        left_costs = sorted({int(row["cost"]) for row in left})
        right_costs = sorted({int(row["cost"]) for row in right})
        row_equal = len(left_costs) == 1 and left_costs == right_costs
        equal = equal and row_equal
        cost_rows.append({"cell": list(key), "unrestricted_costs": left_costs, "support_two_costs": right_costs, "equal": row_equal})

    full_unrestricted = [row for row in rows if row["algorithm"] == "unrestricted" and row["projection"] == "full_subject"]
    full_support_two = [row for row in rows if row["algorithm"] == "support_two" and row["projection"] == "full_subject"]
    scale_three_unrestricted = [row for row in rows if row["algorithm"] == "unrestricted" and row["projection"] == 3]
    scale_three_support_two = [row for row in rows if row["algorithm"] == "support_two" and row["projection"] == 3]
    unrestricted_medians = medians(full_unrestricted)
    support_two_medians = medians(full_support_two)
    ratios = {
        metric: (
            None if unrestricted_medians[metric] in (None, 0) or support_two_medians[metric] is None
            else float(support_two_medians[metric] / unrestricted_medians[metric])
        )
        for metric in METRICS
    }
    positive = False
    done = completed(rows)
    hard_errors = [row["attempt_id"] for row in rows if row["status"] not in ("COMPLETED", "TIMEOUT")]
    return {
        "schema": "anonymous-review.runtime-summary.v2",
        "attempt_counts": {
            "total": len(rows),
            "completed": len(done),
            "timeouts": sum(row["status"] == "TIMEOUT" for row in rows),
            "errors": len(hard_errors),
        },
        "preconditions": {
            "all_measurement_sources_verified_before_run": True,
            "correctness_panel_complete_with_valid_witnesses": complete_valid("unrestricted", correctness_keys) and complete_valid("support_two", correctness_keys),
            "unrestricted_solver_completes_full_subject_panel": complete_valid("unrestricted", full_keys),
            "all_jointly_completed_costs_equal": equal and bool(cost_rows),
            "all_completed_witnesses_valid": all(row.get("witness_valid") is True for row in done),
            "no_non_timeout_execution_errors": not hard_errors,
        },
        "jointly_completed_cells": cost_rows,
        "three_qubit_scale": {
            "unrestricted_timeouts": sum(row["status"] == "TIMEOUT" for row in scale_three_unrestricted),
            "support_two_timeouts": sum(row["status"] == "TIMEOUT" for row in scale_three_support_two),
        },
        "full_subject": {
            "unrestricted_complete": complete_valid("unrestricted", full_keys),
            "support_two_complete": complete_valid("support_two", full_keys),
            "unrestricted_timeouts": sum(row["status"] == "TIMEOUT" for row in full_unrestricted),
            "support_two_timeouts": sum(row["status"] == "TIMEOUT" for row in full_support_two),
            "unrestricted_medians": unrestricted_medians,
            "support_two_medians": support_two_medians,
            "support_two_over_unrestricted_ratios": ratios,
        },
        "positive_performance_rule_satisfied": positive,
        "supported_interpretation": "no measured runtime or memory improvement; all timeout rows are retained",
        "measurement_stack_included": False,
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--write")
    group.add_argument("--check")
    args = parser.parse_args()
    summary = summarize()
    text = json.dumps(summary, indent=2, sort_keys=True) + "\n"
    if args.write:
        (HERE / args.write).write_text(text)
    elif args.check:
        assert json.loads((HERE / args.check).read_text()) == summary
        print("runtime aggregate: PASS")
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
