# Anonymous review materials

This archive accompanies *Support-Two Normal Forms for a Shared-Tag Pauli
Compilation Grammar*.

## Reproduce the finite checks

Use Python 3.11 or newer; no third-party package is required.

```text
python proof_sanity.py
python verify_sharpness.py
```

`proof_sanity.py` exhausts the 192 local correction cases and the odd-parity
class tuples through support eight. `verify_sharpness.py` exhaustively obtains
support-two minimum 5 and support-one minimum 6 for the displayed paired instance.
The latter may take tens of seconds in the reference Python implementation.

`runtime_specification.json` records the pre-measurement design and exact Pauli
subjects in neutral notation. `runtime_attempts.jsonl` contains all 120
sanitized attempt rows, `runtime_environment.json` records the available
environment fields, and `aggregate_runtime.py` deterministically checks the
schedule and regenerates the adverse summary:

```text
python aggregate_runtime.py --check runtime_summary.json
```

The summary retains 108 completions and 12 timeouts, including six
three-qubit and six full-subject direct-solver timeouts. The original
unrestricted measurement stack is not included, so these materials support an
audit of the retained measurements rather than a new timing campaign. The
runtime record is not part of the all-size proof and establishes no performance
improvement.

`literature_boundary.md` records the dated search boundary and a nearest-object
comparison. It supports only the manuscript's bounded positioning and is not a
priority or novelty certificate.

The manuscript source is included under `manuscript_source/`. A standard TeX
installation can build it with:

```text
cd manuscript_source
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The archive contains no author metadata or protected data.
