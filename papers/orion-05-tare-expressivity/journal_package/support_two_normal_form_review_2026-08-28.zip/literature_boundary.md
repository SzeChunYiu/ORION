# Bounded literature and contribution crosswalk

## Search boundary

The search was refreshed through 28 August 2026 using web and arXiv discovery.
Query families combined Tag-and-Restore encoding, shared labels, Pauli frames,
support-two normal forms, exact expressivity, binary-symplectic compilation,
sharp support thresholds, exact and approximate synthesis, low-ancilla block
encodings, fault-tolerant resource models, and compiler benchmarks. Candidate
records were retained when their title, abstract, or accessible full text
concerned the same scientific object or a nearby support-reduction mechanism.
Metadata-only matches that did not expose an assessable scientific claim were
not treated as evidence. Patents, private manuscripts, unindexed software,
non-English sources not located by these channels, and work after the cutoff
were not assessed.

## Nearest-object comparison

| Source family | Scientific object and guarantee | Difference from this paper |
|---|---|---|
| Schillo, Sturm and Quay, version 4, Section 4, Theorems 1-2 and Remarks 1-2 | Tag-and-Restore block encoding with selectable anticommuting frames, controls and compatible label operators | The present paper fixes one six-target specialization and proves a cost-nonincreasing support-two transformation for its declared normalized objective. |
| Izmaylov and coauthors | Grouping anticommuting Pauli terms for measurement | Different task and optimized quantity; no same-object performance comparison is claimed. |
| Cowtan and coauthors; Amy and coauthors | Phase-gadget synthesis and parity-network sharing | Establish support-local decomposition and sharing ideas, not the declared frame-exchange theorem. |
| van den Berg and Temme; PCOAST; PHOENIX; Symphony | Circuit or Hamiltonian transformation in Pauli and binary-symplectic representations | Different compiler objects and guarantees; no same-problem asymptotic improvement is claimed here. |
| DiVincenzo; Fattal and coauthors | Two-qubit universality and stabilizer normal-form foundations | Remove any claim that two-local building blocks or stabilizer reductions originate here. |
| Hastings; Kempe, Kitaev and Regev | Hamiltonian weight reduction, including encodings with additional degrees of freedom or approximation | Different object and preserved quantity from an exact optimum-preserving frame exchange. |

The search did not locate the complete combination of this fixed grammar, this
objective, the coordinate exchange, the exact support-one obstruction, and the
induced direct bound. That statement is a bounded search observation only. It
does not establish absence, priority, broad novelty, significance, or journal
acceptance.
