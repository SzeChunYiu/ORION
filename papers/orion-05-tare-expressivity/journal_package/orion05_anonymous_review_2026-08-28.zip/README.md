# Anonymous review materials

This archive accompanies *Support-Two Normal Forms for a Shared-Tag Pauli
Compilation Grammar*.

## Reproduce the finite checks

Use Python 3.11 or newer; no third-party package is required.

```text
python proof_sanity.py
python verify_sharpness.py
```

`proof_sanity.py` exhausts the 192 local correction cases and the odd-parity
class tuples through support eight. `verify_sharpness.py` recomputes the
displayed paired-instance support-two cost 5 and exhaustive support-one cost 6.
The latter may take tens of seconds in the reference Python implementation.

`exact_comparison_summary.json` reports the bounded comparison against a
separate exact referee. `runtime_summary.json` retains the adverse aggregate:
108 of 120 attempts completed and 12 timed out, including every direct-solver
full-subject attempt. These implementation records are not part of the logical
proof of the all-size theorem and do not establish performance improvement.

The manuscript source is included under `manuscript_source/`. The archive
contains no author identity, development history or protected data.
