#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
load = lambda name: json.loads((HERE / name).read_text())

v2 = load("v2_publication_metrics.json")
v3 = load("v3_panel.json")
x = load("p4x_exact_result.json")
xv = load("p4x_independent_verification.json")

assert v2["case_count"] == 420
assert v2["hypotheses"]["H1"]["status"] == "PASS"
assert v2["hypotheses"]["H2"]["status"] == "PASS"
assert v2["hypotheses"]["H3"]["status"] == "NOT_SUPPORTED"
assert v2["systems"]["ORION"]["false_promotion_rate"] == 0.0
strongest = v2["strongest_frozen_comparator"]
assert v2["systems"][strongest]["false_promotion_rate"] == 0.5
assert v2["systems"]["ORION"]["clean_coverage"] == 1.0
assert v2["systems"][strongest]["clean_coverage"] == 1.0
assert len(v2["ablations"]) == 8

assert v3["case_count"] == 420
assert v3["H3"]["status"] == "SUPPORTED"
cc = v3["cannot_check_family_summary"]
assert cc["ORION"]["correct_terminal"] == 30
assert cc["provenai-citation-fidelity-influence"]["correct_terminal"] == 0
assert cc["deepsciverify-abstract-to-full-escalation"]["correct_terminal"] == 15

assert x["case_count"] == 400
assert x["counts_correct"] == {
    "P4_X": 400,
    "B1_GENERIC_AUTHORIZATION_PRODUCT": 250,
    "B2_COMPENSATORY_PRODUCT": 50,
    "B3_IDEAL_TYPED_PRODUCT": 400,
}
assert x["p4x_minus_b1"] == 0.375
assert x["bootstrap_95_ci"] == [0.3275, 0.4225]
assert x["b3_p4x_decision_mismatches"] == 0
assert xv["imports_original_execution_module"] is False
assert xv["canonical_rows_sha256"] == x["canonical_rows_sha256"]
assert xv["counts_correct"] == x["counts_correct"]

print("ANONYMOUS_REVIEW_HEADLINES_VERIFIED")
