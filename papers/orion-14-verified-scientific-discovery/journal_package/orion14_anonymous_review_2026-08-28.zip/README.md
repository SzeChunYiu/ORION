# Anonymous review artifact

This supplement supports the bounded results reported in the accompanying
manuscript.  It contains safe aggregate result objects for the protected V2
battery, the distinct V3 identifiability/interface battery, and the P4-X exact
scientific-promotion contracts, together with a small verifier for the headline
counts.

## Evidence identities

The three empirical layers are separate experiments and must not be pooled.

- **V2**: finite protected false-promotion / clean-coverage experiment.  Its
  registered H3 comparison is saturated and remains `NOT_SUPPORTED`.
- **V3**: distinct shortcut-resistant exact-axis experiment.  Its positive H3
  result is interpreted only as terminal/interface attainability under the
  frozen gate lattice, not general scientific judgement.
- **P4-X**: 400 heterogeneous exact scientific-promotion contracts comparing a
  target-bound non-compensatory relation with donor-complete generic,
  compensatory, and information-equivalent typed products.  The typed product
  ties exactly, so no centralization or unique-expressivity claim is licensed.

## What is deliberately absent

Protected per-case gold, raw protected execution traces, secret seeds,
credentials, candidate-hidden fields, author identity, public repository URLs,
and operational history are not included.  Their absence is part of
blind review and protected-evaluation custody; it is not presented as full
external reproduction.

Run `python verify_headlines.py` from this directory to verify the headline
counts and retained boundaries from the packaged JSON objects.
